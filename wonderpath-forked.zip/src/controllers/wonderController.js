const index = (req, res) => {
  res.render('wonder/index.njk');
};


module.exports = {index};